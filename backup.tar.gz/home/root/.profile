export REMOTE0="/sys/class/remoteproc/remoteproc0"
export M4FW="/lib/firmware/rproc-m4-fw"
export M4DIR="/usr/local/m4_examples"
